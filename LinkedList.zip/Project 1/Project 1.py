# This is the Array
def readArray():
    with open("data.txt", "r") as file:
        # Read lines into a list
        lines = file.readlines()

        # Initialize an empty list
        inputArray = []

        # Loop through each line
        for line in lines:
            # Remove newline character and any leading/trailing whitespaces
            line = line.strip()

            # Skip empty lines
            if line == '':
                continue

            # Convert each line to integer and append to the list
            inputArray.append(int(line))
                    
        # Sort the list
        inputArray.sort()
        return inputArray

# This is the Node
class Node:
    def __init__(self, d):
        self.Data = d
        self.Next = None

# This is the LinkedList
class LinkedList:
    def __init__(self, d=None):
        if (d == None):
            self.Header = None
            self.Current = None
        else:
            self.Header = Node(d)
            self.Current = self.Header
    
    def insertBeginning(self, d):
        if (self.Header is None):
            self.Header = Node(d)
            self.Current = self.Header
        else:
            Tmp = Node(d)
            Tmp.Next = self.Header
            self.Header = Tmp

    def insertCurrentNext(self, d):
        if (self.Header is None):
            self.Header = Node(d)
            self.Current = self.Header
        else:
            Tmp = Node(d)
            Tmp.Next = self.Current.Next
            self.Current.Next = Tmp

    def removeBeginning(self):
        if (self.Header is None):
            return None
        else:
            ans = self.Header.Data
            self.Header = self.Header.Next
            self.Current = self.Header
            return ans
        
    def removeCurrentNext(self):
        if (self.Current.Next is None):
            return None
        else:
            ans = self.Current.Next.Data
            self.Current.Next = self.Current.Next.Next
            return ans
    
    def nextCurrent(self):
        if (self.Current.Next is not None):
            self.Current = self.Current.Next
        else:
            self.Current = self.Header
    
    def resetCurrent(self):
        self.Current = self.Header
    
    def getCurrent(self):
        if (self.Current is not None):
            return self.Current.Data
        else:
            return None
        
    @staticmethod    
    def createLinkedList(myArray):
        myLinkedList = LinkedList()
        for i in reversed(myArray):
            myLinkedList.insertBeginning(i)
        return myLinkedList
    
    def printList(self):
        current = self.Header
        while current:
            print(current.Data, end = " ")
            current = current.Next

# This is the function you need to implement
    def insert(self, data):
        if self.Header is None:
            self.Header = Node(data)
        else:
            current = self.Header
            previous = None
            while current is not None:
                if current.Data == data:
                    if previous is not None:
                        previous.Next = current.Next
                    else:
                        self.Header = current.Next
                    break
                if current.Data > data:
                    if previous is not None:
                        previous.Next = Node(data)
                        if previous.Next is not None:
                            previous.Next.Next = current
                    else:
                        self.Header = Node(data)
                        self.Header.Next = current
                    break
                previous = current
                current = current.Next
                if current is None:
                    previous.Next = Node(data)
                        
# Main function
class Project1:
    @staticmethod
    def main():
        myArray = readArray()
        print(myArray)
        myLinkedList = LinkedList.createLinkedList(myArray)
        myIntValue = Project1.getInt()
        myLinkedList.insert(myIntValue)
        myLinkedList.printList()

    @staticmethod
    def getInt():
        while True:
            try:
                intValue = int(input("Enter a number: "))
                return intValue
            except ValueError:
                print("Invalid input. Try again.")
                continue

Project1.main()






        


