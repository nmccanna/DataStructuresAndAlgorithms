# 1) A
import math

# Count Binary Digits Method
def countBinaryDigits(n):
    if n == 1:
        return 1
    else:
        return 1 + countBinaryDigits(math.floor(n/2))

# 1) B
# Print Results
print(countBinaryDigits(256))  # Output: 9
print(countBinaryDigits(750))  # Output: 10

'''
1     0    0    0     0     0      0     0     0
2^8  2^7  2^6  2^5   2^4   2^3    2^2    2^1   2^0
256   0    0    0     0     0      0     0     0

1     0    1    1       1   0     1    1   1   0
2^9  2^8  2^7  2^6    2^5  2^4  2^3  2^2  2^1  2^0
512   0    128  64     32   0   8    4    2    0

'''

