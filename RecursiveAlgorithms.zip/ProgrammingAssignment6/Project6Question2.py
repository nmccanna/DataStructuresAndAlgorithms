#2) A
# Sum of Squares Method
def sumOfSquares(n):
    if n == 1:
        return 1
    else:
        return sumOfSquares(n - 1) + n ** 2

# 2) B
# Print Results
print(sumOfSquares(12))  # Output: 650
print(sumOfSquares(20))  # Output: 2870

