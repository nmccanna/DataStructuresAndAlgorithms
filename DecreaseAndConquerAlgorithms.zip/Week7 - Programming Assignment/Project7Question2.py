# 2.) A.

# Method for binary search
def binarySearch(A, left, right, key):
    if right >= left:
        mid = left + (right - left) // 2
        print(mid)

        # If element is present at the middle itself
        if A[mid] == key:
            return mid

        # If the element is larger than mid, then it can only be in the left subarray
        elif A[mid] < key:
            return binarySearch(A, left, mid-1, key)

        # Else the element can only be in the right subarray
        else:
            return binarySearch(A, mid+1, right, key)

    else:
        # The element is not in the array
        return None

# 2.) B.
# Test the function

A = [100, 87, 85, 80, 72, 67, 55, 50, 48, 42, 40, 31, 25, 22, 18]

# Test cases
key = 87
#key = 48
#key = 33
#key = 10

result = binarySearch(A, 0, len(A)-1, key)
if result != None:
    # Element is present in the array
    print(f'Element is present at index: {str(result)}')
else:
    # Element is not present in the array
    print('Element is not present in the array.')
