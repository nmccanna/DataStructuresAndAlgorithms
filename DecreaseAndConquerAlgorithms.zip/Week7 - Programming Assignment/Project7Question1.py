# 1.) A.
# Method to calculate the mean of a list of numbers

def mean(A, n):
    # Base case: if n is 1, return the only element
    if n == 1:
        return A[0]
    
    # Recursive case: 
    return ((mean(A, n-1)*(n-1)) + A[n-1]) / n

# 1.) B.
# Test cases

A = [12, 23, 37, 45, 63, 82, 47, 75, 91, 88, 102]
print(mean(A, 11)) # Output should be the mean of the list A

# A = [1.7, 6.5, 8.2, 0.0, 4.7, 6.3, 9.5, 12.2, 37.9, 53.2]
# print(mean(A, 10)) # Output should be the mean of the list A
