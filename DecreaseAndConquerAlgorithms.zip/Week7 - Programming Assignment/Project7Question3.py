# 3.) A.

# Method to calculate the GCD of two numbers 
def GCD(a, b):
    print(f"Calculating GCD of {a} and {b}")
    # Base case: if b is 0, return a
    if b == 0:
        return a
    # Recursive case:
    else:
        return GCD(b, a % b)

# 3.) B.
# Test cases

a = 2468
b = 1357

# a = 111
# b = 378

# a = 123456789
# b = 987654321

result = GCD(a, b)
print(f"The GCD of {a} and {b} is {result}")
