# Node class
class Node:
    def __init__(self, d):
        self.Data, self.Left, self.Right = d, None, None
        self.Index = 0

# Tree class
class Tree:
    def __init__(self, d=None):
        if (d == None): # an empty tree
            self.Root = None
        else:
            self.Root = Node(d)
        self.graph = []
        self.totalNodes = 0
        self.nodeList = []

    # Read numbers.txt and insert them into the tree
    def read(self, filename):
        with open(filename) as f:
            for line in f:
                self.insert(int(line))
                self.totalNodes += 1

    def insert(self, d):
        def __insertHere__(n, d):
            if (n.Data > d):   # if no node left insert here
                if (n.Left == None):
                    n.Left = Node(d)
                else:          # or try left child
                    __insertHere__(n.Left, d)
            elif (n.Data < d): # if no node right insert here
                if (n.Right == None):
                    n.Right = Node(d)
                else:          # or try right child
                    __insertHere__(n.Right, d)
        if (self.Root == None): # it was an empty tree
            self.Root = Node(d)
        else:
            if (self.Root.Data > d):          # try left child
                if (self.Root.Left == None):  # if empty insert here
                    self.Root.Left = Node(d)
                else:                         # try left subtree
                    __insertHere__(self.Root.Left, d)
            elif (self.Root.Data < d):        # try right child
                if (self.Root.Right == None): # if empty insert here
                    self.Root.Right = Node(d)
                else:                         # try right subtree
                    __insertHere__(self.Root.Right, d)
    
    def check(self, d):
        def __check__(n, d):
            if (n == None):
                return False
            elif (n.Data == d):
                return True
            elif (n.Data > d):
                return __check__(n.Left, d)
            elif (n.Data < d):
                return __check__(n.Right, d)
        return __check__(self.Root, d)
    
    # Print in order
    def printInorder(self):
        def __visit__(n):
            if (n != None):
                __visit__(n.Left)
                print(n.Data, end=" ")
                __visit__(n.Right)
        print("\n--------")
        __visit__(self.Root)
        print("\n--------")
    
    # Print weight
    def printWeight(self, node1, node2):
        bigger = max(node1.Data, node2.Data)
        smaller = min(node1.Data, node2.Data)
        print("node1 node2 weight:", bigger, smaller, self.getWeight(node1, node2))

    # Get weight
    def getWeight(self, node1, node2):
        bigger = max(node1.Data, node2.Data)
        smaller = min(node1.Data, node2.Data)
        weight = bigger - smaller
        return weight
    
    # Print preorder
    def printPreorder(self):
        def __visit__(parent, level):
            weight = 0
            bigger = 0
            smaller = 0
            if (parent != None):
                if parent.Left != None:
                    print("---" *level, parent.Left.Data)
                    self.printWeight(parent, parent.Left)
                    __visit__(parent.Left, level + 1)
                if parent.Right != None:
                    print("---" *level, parent.Right.Data)
                    self.printWeight(parent, parent.Right)
                    __visit__(parent.Right, level + 1)
        print("^^^^^^^^^^")
        __visit__(self.Root, 1)
        print("^^^^^^^^^^")

    # Graph preorder
    def graphPreorder(self):
        def __visit__(parent, level):
            weight = 0
            bigger = 0
            smaller = 0
            if (parent != None):
                if parent.Left != None:
                    weight = self.getWeight(parent, parent.Left)
                    self.graph.append([parent.Data, parent.Left.Data, weight])
                    self.nodeList.append(parent.Left.Data)
                    __visit__(parent.Left, level + 1)
                if parent.Right != None:
                    weight = self.getWeight(parent, parent.Right)
                    self.graph.append([parent.Data, parent.Right.Data, weight])
                    self.nodeList.append(parent.Right.Data)
                    __visit__(parent.Right, level + 1)
        print("^^^^^^^^^^")
        self.nodeList.append(self.Root.Data)
        __visit__(self.Root, 1)
        print("^^^^^^^^^^")
    
    def printPostorder(self):
        def __visit__(n, h):
            if (n != None):
                __visit__(n.Left, h+1)
                __visit__(n.Right, h+1)
                print("---"*h, n.Data)
        print("==========")
        __visit__(self.Root, 1)
        print("==========")

    # convert list to matrix
    def listToMatrix(self, size):
        matrix = [[0] * size for _ in range(size)]
        for i in range(len(self.graph)):
            column = self.getIndex(self.graph[i][0])
            row = self.getIndex(self.graph[i][1])
            matrix[column][row] = self.graph[i][2]
        #print(matrix)
        return matrix
    
    def getIndex(self, nodeValue):
        for i in range(len(self.nodeList)):
            if nodeValue == self.nodeList[i]:
                return i
        return -1
    
def main():
    myTree = Tree()
    myTree.read("numbers.txt")
    #myTree.printInorder()
    #myTree.printInorder()
    #myTree.printPostorder()
    #myTree.printPreorder()
    myTree.graphPreorder()
    #print(myTree.nodeList)
    myMatrix = myTree.listToMatrix(myTree.totalNodes)
    #print("56 is in the tree:", myTree.check(56))
    #print("17 is in the tree:", myTree.check(17))
    #print("25 is in the tree:", myTree.check(25))
    #print("15 is in the tree:", myTree.check(15))
    #myTree.printPostorder()
    #print(myTree.graph)
    #print(myMatrix)
    for i in range(myTree.totalNodes-1):
        print(myMatrix[i])


main()
