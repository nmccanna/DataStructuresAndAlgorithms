import csv

class Person:
    def __init__(self, name, familyName, age):
        self.name = name
        self.famN = familyName
        self.age = age

    def getName(self):
        return self.name
    
    def getFullName(self):
        return self.name + " " + self.famN
    
    def getFamilyName(self):
        return self.famN
    
    def getAge(self):
        return self.age

# Read people from file and create stack
stack = []
with open('people.csv', 'r') as csvfile:
    csvreader = csv.reader(csvfile)
    for row in csvreader:
        stack.append(Person(row[0], row[1], row[2]))

while stack:
    # Prompt user for number of people to pop
    try:
        num_to_pop = input("Enter a number from 1 to 4: ")
        int_to_pop = int(num_to_pop)
        if int_to_pop < 1 or int_to_pop > 4:
            raise ValueError
    except ValueError:
        print("Invalid input. Exiting.")
        quit()

    # Check if stack is empty
    if int_to_pop > len(stack):
        print("Stack is empty. Exiting.")
        break

    # Pop the specified number of people from the stack
    for _ in range(int_to_pop):
        stack.pop()

    if stack:
        # Print the name of the remaining person on top of the stack
        print("Remaining person:", stack[-1].getFullName(), stack[-1].getAge())
    else:
        print("Stack is empty. Exiting.")



